var searchData=
[
  ['message',['message',['../main_8c.html#ad644d7ab54692eb2518cdf3c8da50a6f',1,'main.c']]],
  ['minutes',['minutes',['../structtime_struct.html#a5c2cca19ef619fa7a9fcfcfcd46d895a',1,'timeStruct']]]
];
