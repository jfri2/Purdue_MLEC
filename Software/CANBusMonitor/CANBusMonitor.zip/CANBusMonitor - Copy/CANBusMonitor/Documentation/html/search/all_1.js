var searchData=
[
  ['adcvoltage',['adcVoltage',['../main_8c.html#acad6eebce40aff54c96c90f3d7e62c30',1,'main.c']]]
];
