var searchData=
[
  ['f_5fcpu',['F_CPU',['../config_8h.html#a43bafb28b29491ec7f871319b5a3b2f8',1,'config.h']]],
  ['fosc',['FOSC',['../config_8h.html#a802b2b582b121e4632aa9a491d503720',1,'config.h']]]
];
