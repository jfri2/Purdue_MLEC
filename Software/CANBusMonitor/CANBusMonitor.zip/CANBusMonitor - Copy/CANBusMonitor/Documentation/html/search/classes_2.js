var searchData=
[
  ['timestruct',['timeStruct',['../structtime_struct.html',1,'']]]
];
