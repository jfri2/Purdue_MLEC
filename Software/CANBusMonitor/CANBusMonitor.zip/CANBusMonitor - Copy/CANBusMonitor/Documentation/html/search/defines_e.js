var searchData=
[
  ['uart_5fbaud_5frate',['UART_BAUD_RATE',['../config_8h.html#a615aed21aa6825462b7c17b0c238ffe2',1,'config.h']]]
];
