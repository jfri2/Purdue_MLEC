var searchData=
[
  ['event_5flogger_2ec',['event_logger.c',['../event__logger_8c.html',1,'']]],
  ['event_5flogger_2eh',['event_logger.h',['../event__logger_8h.html',1,'']]]
];
