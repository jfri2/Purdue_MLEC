var searchData=
[
  ['logevent',['logEvent',['../event__logger_8c.html#a7bfc3cdd52720934db0a187b1547f9af',1,'logEvent(char *str):&#160;event_logger.c'],['../event__logger_8h.html#a7bfc3cdd52720934db0a187b1547f9af',1,'logEvent(char *str):&#160;event_logger.c']]]
];
