var searchData=
[
  ['system_5finit',['system_init',['../config_8h.html#a43f5e0d6db0fb41a437cc9096b32e9b5',1,'system_init(void):&#160;main.c'],['../main_8c.html#a43f5e0d6db0fb41a437cc9096b32e9b5',1,'system_init(void):&#160;main.c']]]
];
