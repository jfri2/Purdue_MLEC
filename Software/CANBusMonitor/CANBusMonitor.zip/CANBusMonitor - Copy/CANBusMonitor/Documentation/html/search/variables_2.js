var searchData=
[
  ['days',['days',['../structtime_struct.html#a4464eb87414c4ce8bd7e466f0887866a',1,'timeStruct']]],
  ['dlc',['dlc',['../structst__cmd__t.html#a0f1031116dcd5cc10d4afee0550363ba',1,'st_cmd_t']]]
];
