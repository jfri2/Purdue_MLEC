CANBusMonitor
Ind. Study Project
Purdue University

Author: John Fritz
Created: 06 Mar 2016
Updated: 21 Mar 2016

CAN monitor implemented reporting over UART. Max UART baud 19200 bit/sec

Notes: 
SUT_CKSEL fuse needs to be changed to EXTXOSC_8MHZ_XX_16KCK_14CK_4MS1